package com.datridha.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Typeface;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.content.Intent;
import android.net.Uri;

public class MainActivity extends Activity {
    private boolean arabic = true;
    private LinearLayout root;
    private TextView title, subtitle, language;
    private Button buy, sell, orders, contact;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        showArabic();
    }

    private Button button(String text) {
        Button x = new Button(this);
        x.setText(text);
        x.setTextSize(17);
        root.addView(x, new LinearLayout.LayoutParams(-1, -2));
        return x;
    }

    private void build() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(32, 40, 32, 32);

        language = new TextView(this);
        language.setGravity(Gravity.CENTER);
        language.setTextSize(16);
        root.addView(language, new LinearLayout.LayoutParams(-1, -2));

        title = new TextView(this);
        title.setTextSize(30);
        title.setTypeface(null, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        subtitle = new TextView(this);
        subtitle.setTextSize(18);
        subtitle.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, -2);
        sp.setMargins(0, 8, 0, 28);
        root.addView(subtitle, sp);

        buy = button("");
        sell = button("");
        orders = button("");
        contact = button("");

        language.setOnClickListener(v -> { arabic = !arabic; updateText(); });
        buy.setOnClickListener(v -> toast(arabic ? "قسم شراء دقلة النور بالجملة" : "Achat de Deglet Nour en gros"));
        sell.setOnClickListener(v -> toast(arabic ? "قسم بيع دقلة النور بالجملة" : "Vente de Deglet Nour en gros"));
        orders.setOnClickListener(v -> toast(arabic ? "لا توجد طلبات جديدة حاليًا" : "Aucune nouvelle commande pour le moment"));
        contact.setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:"));
            startActivity(i);
        });

        setContentView(root);
        updateText();
    }

    private void updateText() {
        if (root == null) { build(); return; }
        root.setLayoutDirection(arabic ? android.view.View.LAYOUT_DIRECTION_RTL : android.view.View.LAYOUT_DIRECTION_LTR);
        language.setText(arabic ? "العربية  |  Français" : "Français  |  العربية");
        title.setText("DATRIDHA");
        subtitle.setText(arabic ? "دقلة النور من بشني • تجارة بالجملة" : "Deglet Nour de Bechni • Commerce en gros");
        buy.setText(arabic ? "شراء دقلة النور" : "Acheter Deglet Nour");
        sell.setText(arabic ? "بيع دقلة النور" : "Vendre Deglet Nour");
        orders.setText(arabic ? "الطلبات" : "Commandes");
        contact.setText(arabic ? "تواصل معنا" : "Nous contacter");
    }

    private void showArabic() { build(); }
    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }
}
