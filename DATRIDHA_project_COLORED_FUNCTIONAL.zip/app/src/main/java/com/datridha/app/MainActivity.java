package com.datridha.app;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    private LinearLayout root;
    private boolean french = false;
    private final List<String> orders = new ArrayList<>();
    private int green = Color.rgb(44, 104, 55);
    private int gold = Color.rgb(196, 137, 35);
    private int cream = Color.rgb(255, 248, 232);
    private int dark = Color.rgb(45, 45, 45);

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        showHome();
    }

    private TextView text(String s, float size, int color, boolean bold) {
        TextView v = new TextView(this); v.setText(s); v.setTextSize(size); v.setTextColor(color);
        v.setGravity(Gravity.CENTER); v.setPadding(16, 12, 16, 12);
        if (bold) v.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return v;
    }

    private Button button(String label) {
        Button b = new Button(this); b.setText(label); b.setTextSize(17); b.setTextColor(Color.WHITE);
        b.setAllCaps(false); b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setBackgroundColor(green); b.setPadding(8, 10, 8, 10);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, 62); p.setMargins(0, 8, 0, 8); b.setLayoutParams(p);
        return b;
    }

    private EditText field(String hint, int type) {
        EditText e = new EditText(this); e.setHint(hint); e.setTextSize(16); e.setPadding(20, 8, 20, 8);
        e.setInputType(type); e.setBackgroundColor(Color.WHITE);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, 58); p.setMargins(0, 6, 0, 6); e.setLayoutParams(p); return e;
    }

    private void base(String title) {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(22, 18, 22, 22); root.setBackgroundColor(cream);
        ScrollView scroll = new ScrollView(this); scroll.addView(root); setContentView(scroll);
        TextView bar = text(title, 22, Color.WHITE, true); bar.setBackgroundColor(green); root.addView(bar, new LinearLayout.LayoutParams(-1, 64));
    }

    private void backButton() {
        Button b = button(french ? "← Accueil" : "← الرئيسية"); b.setBackgroundColor(gold); b.setOnClickListener(v -> showHome()); root.addView(b);
    }

    private void showHome() {
        base("");
        LinearLayout langs = new LinearLayout(this); langs.setGravity(Gravity.CENTER); 
        Button fr = new Button(this); fr.setText("Français"); fr.setAllCaps(false); fr.setOnClickListener(v -> { french = true; showHome(); });
        Button ar = new Button(this); ar.setText("العربية"); ar.setAllCaps(false); ar.setOnClickListener(v -> { french = false; showHome(); });
        langs.addView(fr, new LinearLayout.LayoutParams(0, 55, 1)); langs.addView(ar, new LinearLayout.LayoutParams(0, 55, 1)); root.addView(langs);

        TextView logo = text("DATRIDHA", 34, green, true); root.addView(logo);
        TextView sub = text(french ? "Deglet Nour de Bechni\nCommerce de gros" : "دقلة النور من بشني\nتجارة بالجملة", 19, dark, true); root.addView(sub);

        Button buy = button(french ? "🌴 Acheter Deglet Nour" : "🌴 شراء دقلة النور"); buy.setOnClickListener(v -> showBuy()); root.addView(buy);
        Button sell = button(french ? "📦 Vendre Deglet Nour" : "📦 بيع دقلة النور"); sell.setOnClickListener(v -> showSell()); root.addView(sell);
        Button ordersBtn = button(french ? "🛒 Mes commandes" : "🛒 الطلبات"); ordersBtn.setOnClickListener(v -> showOrders()); root.addView(ordersBtn);
        Button contact = button(french ? "📞 Nous contacter" : "📞 تواصل معنا"); contact.setOnClickListener(v -> showContact()); root.addView(contact);
    }

    private void showBuy() {
        base(french ? "Acheter Deglet Nour" : "شراء دقلة النور");
        root.addView(text(french ? "Deglet Nour de Bechni – Vente en gros" : "دقلة النور من بشني – بيع بالجملة", 21, green, true));
        root.addView(text(french ? "Indiquez la quantité souhaitée et envoyez votre demande." : "أدخل الكمية المطلوبة وأرسل طلبك.", 16, dark, false));
        EditText q = field(french ? "Quantité (kg)" : "الكمية (كغ)", InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL); root.addView(q);
        EditText phone = field(french ? "Téléphone" : "رقم الهاتف", InputType.TYPE_CLASS_PHONE); root.addView(phone);
        EditText note = field(french ? "Message / qualité souhaitée" : "ملاحظة / الجودة المطلوبة", InputType.TYPE_CLASS_TEXT); root.addView(note);
        Button send = button(french ? "Envoyer la demande" : "إرسال طلب الشراء"); send.setOnClickListener(v -> {
            if (q.getText().toString().trim().isEmpty() || phone.getText().toString().trim().isEmpty()) { toast(french ? "Veuillez remplir la quantité et le téléphone." : "يرجى إدخال الكمية ورقم الهاتف."); return; }
            orders.add((french ? "Achat de " : "شراء ") + q.getText() + " kg – " + phone.getText()); toast(french ? "Demande enregistrée." : "تم تسجيل طلبك."); showOrders();
        }); root.addView(send); backButton();
    }

    private void showSell() {
        base(french ? "Vendre Deglet Nour" : "بيع دقلة النور");
        root.addView(text(french ? "Proposez votre Deglet Nour aux acheteurs en gros." : "اعرض دقلة النور الخاصة بك على المشترين بالجملة.", 19, green, true));
        EditText q = field(french ? "Quantité disponible (kg)" : "الكمية المتوفرة (كغ)", InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL); root.addView(q);
        EditText price = field(french ? "Prix souhaité (DT/kg)" : "السعر المطلوب (د.ت/كغ)", InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL); root.addView(price);
        EditText phone = field(french ? "Téléphone" : "رقم الهاتف", InputType.TYPE_CLASS_PHONE); root.addView(phone);
        Button send = button(french ? "Publier mon offre" : "نشر عرض البيع"); send.setOnClickListener(v -> {
            if (q.getText().toString().trim().isEmpty() || phone.getText().toString().trim().isEmpty()) { toast(french ? "Veuillez remplir la quantité et le téléphone." : "يرجى إدخال الكمية ورقم الهاتف."); return; }
            orders.add((french ? "Offre de vente : " : "عرض بيع: ") + q.getText() + " kg" + (price.getText().length()>0 ? " – " + price.getText() + " DT/kg" : "")); toast(french ? "Offre enregistrée." : "تم تسجيل عرض البيع."); showOrders();
        }); root.addView(send); backButton();
    }

    private void showOrders() {
        base(french ? "Mes commandes" : "الطلبات");
        if (orders.isEmpty()) root.addView(text(french ? "Aucune commande pour le moment." : "لا توجد طلبات حاليًا.", 18, dark, false));
        else for (String o : orders) { TextView item = text("• " + o, 17, dark, false); item.setGravity(Gravity.START); item.setBackgroundColor(Color.WHITE); root.addView(item); }
        backButton();
    }

    private void showContact() {
        base(french ? "Nous contacter" : "تواصل معنا");
        root.addView(text("DATRIDHA", 30, green, true));
        root.addView(text(french ? "Pour les achats, ventes et informations, contactez-nous." : "للاستفسار حول الشراء والبيع والمعلومات، تواصل معنا.", 18, dark, false));
        Button call = button(french ? "📞 Appeler" : "📞 الاتصال بنا"); call.setOnClickListener(v -> toast(french ? "Ajoutez votre numéro de contact dans cette page." : "يمكن إضافة رقم الهاتف في هذه الصفحة.")); root.addView(call);
        Button msg = button(french ? "✉ Envoyer un message" : "✉ إرسال رسالة"); msg.setOnClickListener(v -> toast(french ? "Fonction de messagerie prête à être connectée." : "وظيفة الرسائل جاهزة للربط لاحقًا.")); root.addView(msg);
        backButton();
    }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }
}
