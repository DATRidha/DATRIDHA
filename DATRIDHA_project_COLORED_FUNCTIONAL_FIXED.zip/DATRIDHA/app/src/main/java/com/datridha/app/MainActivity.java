package com.datridha.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private LinearLayout root;
    private int green = Color.rgb(31, 120, 70);
    private int gold = Color.rgb(214, 155, 45);
    private int dark = Color.rgb(35, 45, 38);
    private boolean french = false;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        showHome();
    }

    private TextView text(String s, float size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setGravity(Gravity.CENTER); t.setPadding(16, 10, 16, 10);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private Button actionButton(String label, int color) {
        Button b = new Button(this);
        b.setText(label); b.setTextSize(18); b.setTextColor(Color.WHITE);
        b.setAllCaps(false); b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        GradientDrawable bg = new GradientDrawable(); bg.setColor(color); bg.setCornerRadius(28);
        b.setBackground(bg); b.setPadding(10, 8, 10, 8);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, 68); p.setMargins(0, 8, 0, 8);
        b.setLayoutParams(p); return b;
    }

    private void base(String title, String subtitle) {
        ScrollView scroll = new ScrollView(this);
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(28, 24, 28, 28);
        root.setBackgroundColor(Color.rgb(250, 247, 239)); scroll.addView(root);
        LinearLayout langs = new LinearLayout(this); langs.setGravity(Gravity.CENTER);
        Button fr = new Button(this); fr.setText("Français"); fr.setAllCaps(false); fr.setOnClickListener(v -> { french=true; showHome(); });
        Button ar = new Button(this); ar.setText("العربية"); ar.setAllCaps(false); ar.setOnClickListener(v -> { french=false; showHome(); });
        langs.addView(fr); langs.addView(ar); root.addView(langs);
        TextView h = text(title, 30, green, true); h.setPadding(8, 18, 8, 4); root.addView(h);
        root.addView(text(subtitle, 18, dark, false));
        setContentView(scroll);
    }

    private void showHome() {
        base("DATRIDHA", french ? "Deglet Nour de Bechni • Commerce de gros" : "دقلة النور من بشني • تجارة بالجملة");
        String buy = french ? "Acheter Deglet Nour" : "شراء دقلة النور";
        String sell = french ? "Vendre Deglet Nour" : "بيع دقلة النور";
        String orders = french ? "Commandes" : "الطلبات";
        String contact = french ? "Contactez-nous" : "تواصل معنا";
        Button b1=actionButton(buy,green), b2=actionButton(sell,gold), b3=actionButton(orders,Color.rgb(52,102,160)), b4=actionButton(contact,Color.rgb(110,70,130));
        b1.setOnClickListener(v -> showPage(buy, french ? "Products available for wholesale purchase" : "الدقلة المتوفرة للشراء بالجملة", new String[]{french?"Quantity: kg / tons":"الكمية: كغ / طن", french?"Price: after registration":"السعر: بعد التسجيل", french?"Send purchase request":"إرسال طلب شراء"}));
        b2.setOnClickListener(v -> showPage(sell, french ? "Offer your Deglet Nour for wholesale sale" : "اعرض دقلة النور للبيع بالجملة", new String[]{french?"Quantity available: kg / tons":"الكمية المتوفرة: كغ / طن", french?"Quality and origin: Bechni":"الجودة والمنشأ: بشني", french?"Send sale offer":"إرسال عرض بيع"}));
        b3.setOnClickListener(v -> showPage(orders, french ? "Your purchase and sale requests" : "طلبات الشراء والبيع الخاصة بك", new String[]{french?"No orders yet":"لا توجد طلبات بعد", french?"New requests will appear here":"ستظهر الطلبات الجديدة هنا"}));
        b4.setOnClickListener(v -> showPage(contact, french ? "We are here to help you" : "نحن هنا لمساعدتك", new String[]{french?"Phone / WhatsApp":"الهاتف / واتساب", french?"Wholesale Deglet Nour from Bechni":"تجارة دقلة النور بالجملة من بشني", french?"Contact the DATRIDHA team":"تواصل مع فريق DATRIDHA"}));
        root.addView(b1);root.addView(b2);root.addView(b3);root.addView(b4);
    }

    private void showPage(String title, String subtitle, String[] lines) {
        base(title, subtitle);
        for (String line: lines) { TextView v=text(line,17,dark,false); v.setBackgroundColor(Color.WHITE); v.setPadding(20,18,20,18); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2); p.setMargins(0,8,0,8); root.addView(v,p); }
        Button back=actionButton(french?"Retour":"رجوع",green); back.setOnClickListener(v->showHome()); root.addView(back);
    }
}
