package com.datridha.app;
import android.app.*; import android.os.*; import android.graphics.Typeface; import android.view.*; import android.widget.*;
public class MainActivity extends Activity {
 public void onCreate(Bundle b){super.onCreate(b); LinearLayout r=new LinearLayout(this); r.setOrientation(LinearLayout.VERTICAL); r.setPadding(32,48,32,32);
 TextView t=new TextView(this); t.setText("DATRIDHA\nدقلة النور • تجارة بالجملة"); t.setTextSize(27); t.setGravity(17); t.setTypeface(null,Typeface.BOLD); r.addView(t,new LinearLayout.LayoutParams(-1,-2));
 String[] a={"شراء دقلة النور","بيع دقلة النور","الطلبات","تواصل معنا"}; for(String s:a){Button x=new Button(this);x.setText(s);r.addView(x,new LinearLayout.LayoutParams(-1,-2));} setContentView(r); }
}
